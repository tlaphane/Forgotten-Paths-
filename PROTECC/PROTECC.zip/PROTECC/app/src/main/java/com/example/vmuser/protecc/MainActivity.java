package com.example.vmuser.protecc;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by vmuser on 2019/05/16.
 */

public class MainActivity extends AppCompatActivity{
            @Override
            protected void onCreate(Bundle bundle) {
                super.onCreate(bundle);
                setContentView(R.layout.activity_main);
            }


}
