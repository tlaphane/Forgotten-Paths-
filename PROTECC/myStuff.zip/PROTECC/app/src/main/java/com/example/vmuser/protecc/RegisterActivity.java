package com.example.vmuser.protecc;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;

/**
 * Created by vmuser on 2019/05/16.
 */

public class RegisterActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.register);


        EditText name = findViewById(R.id.edname);

    }
}
